library(rJava)
library(bnlearn)

library(RBGL)
library(gRbase)
library(gRain)
library(RMySQL)
library(ROCR)
library(sampling)
library(xlsx)
library(arules)
library(RWeka)

rm(list=ls()) 
cat("\014") 

#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

## check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "allcust_hour_tou")
# delete column read_time from this table
drops <- c("read_time")
allcust_hour <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
allcust_hour=allcust_hour[sample(nrow(allcust_hour)),];  

summary(allcust_hour);
colnames(allcust_hour) <- c("Month","Hour","Demand_t","Demand_t_1","Demand_t_2",
                            "Price","temperature","Dayofweek","Isweekend")      

#define factors for some vectors
Month<- factor(allcust_hour$Month)
Hour <- factor(allcust_hour$Hour)
Dayofweek <- factor(allcust_hour$Dayofweek)
Isweekend <- factor(allcust_hour$Isweekend)


### discretize class variable by k-means clustering 
Demand_t=arules::discretize(allcust_hour$Demand_t,'interval',categories=3);
summary(Demand_t)

#case 4 discretization by Rweka Fayyad and Irani MDL tool (supervised)
Demand_t_1=allcust_hour$Demand_t_1
Demand_t_2=allcust_hour$Demand_t_2
Price=allcust_hour$Price
temperature=allcust_hour$temperature
mydata=data.frame(Month,Hour,Demand_t,Demand_t_1,Demand_t_2,Price,temperature,Dayofweek,Isweekend);
data <- RWeka::Discretize(Demand_t ~., data = mydata)
summary(data)



from = c("temperature","Price","Month","Dayofweek","Isweekend","Demand_t","Demand_t_1","Demand_t_2",
         "temperature","Price","Hour","Dayofweek","Isweekend","Demand_t","Demand_t_1","Demand_t_2",
         "temperature","Price","Month","Hour","Isweekend","Demand_t","Demand_t_1","Demand_t_2",
         "temperature","Price","Month","Hour","Demand_t","Demand_t_1","Demand_t_2",
         "Price","Dayofweek","Isweekend","Demand_t","Demand_t_1","Demand_t_2",
         "Demand_t","Demand_t_1",
         "Demand_t");

to=c("Hour","Hour","Hour","Hour","Hour","Hour","Hour","Hour",
     "Month","Month","Month","Month","Month","Month","Month","Month",
     "Dayofweek","Dayofweek","Dayofweek","Dayofweek","Dayofweek","Dayofweek","Dayofweek","Dayofweek",
     "Isweekend","Isweekend","Isweekend","Isweekend","Isweekend","Isweekend","Isweekend",
     "temperature","temperature","temperature","temperature","temperature","temperature",
     "Demand_t_2","Demand_t_2",
     "Demand_t_1")

blacklist = data.frame(from = from,to=to);



#learning network structure
tan=hc(data,score='bic',blacklist=blacklist);


tan=hc(data,score='bic');

plot(tan)

dsep(tan,"Price","Demand_t","Month")


#plot  advanced BN using Rgraphviz
adjan=amat(tan)
mybn<-new("graphAM", adjMat=adjan, edgemode="directed")
plot(mybn,y="dot",attrs = list(node = list(fillcolor = "lightblue",fontsize=14,width=1.2),
                               edge = list(arrowsize=0.5)))




#cross validation
bncv1=bn.cv(data,tan,loss='logl',k=10,fit="bayes");
bncv2=bn.cv(data,tan,loss="pred",loss.args=list(target="Demand_t"),k=10,fit="bayes");
bncv1
bncv2










#fit the network
tan.fit = bn.fit(tan, train, method = "bayes")
tan.predict = predict(tan.fit,data=test,node="Demand_t");
confusion=table(test[,"Demand_t"],tan.predict);
confusion


#exact inference with gRain (junction tree), 
jtree=compile(as.grain(tan.fit))   #export the network to grain
querygrain(jtree,nodes="Demand_t")$Demand_t #no evidence at all



#set the evidence
levels(data$Demand_t)=c("Low","AVG","High");
summary(data$Price)
levels=levels(data$Price)


#no evidence about price
jprop0=setFinding(jtree,nodes=c("Month","Hour"),states=c("5","18"))
querygrain(jprop0,nodes="Demand_t")$Demand_t

# with evidence about price

state=levels[[4]]
state
jprop=setFinding(jtree,nodes=c("Month","Hour","Price"),states=c("5","18",state))
querygrain(jprop,nodes="Demand_t")$Demand_t





#Compute evaluation measures for each class
TP1=confusion[[1]]
TP2=confusion[[5]]
TP3=confusion[[9]]

FP1 <-sum(confusion[,1])-TP1
FP2 <-sum(confusion[,2])-TP2
FP3 <-sum(confusion[,3])-TP3

FN1 <-sum(confusion[1,])-TP1
FN2 <-sum(confusion[2,])-TP2
FN3 <-sum(confusion[3,])-TP3

TN1=sum(confusion)-(TP1+FP1+FN1)
TN2=sum(confusion)-(TP2+FP2+FN2)
TN3=sum(confusion)-(TP3+FP3+FN3)

accuracy1 <- (TP1+TN1)/(TP1+TN1+FP1+FN1)
recall1 <- TP1/(TP1+FN1)
precision1 <- TP1/(TP1+FP1)
type1error1=FP1/(FP1+TN1)
type2error1=FN1/(TP1+FN1)
type1error1
type2error1


accuracy2 <- (TP2+TN2)/(TP2+TN2+FP2+FN2)
recall2 <- TP2/(TP2+FN2)
precision2 <- TP2/(TP2+FP2)
type1error2=FP2/(FP2+TN2)
type2error2=FN2/(TP2+FN2)
type1error2
type2error2

accuracy3 <- (TP3+TN3)/(TP3+TN3+FP3+FN3)
recall3 <- TP3/(TP3+FN3)
precision3 <- TP3/(TP3+FP3)
type1error3=FP3/(FP3+TN3)
type2error3=FN3/(TP3+FN3)
type1error3
type2error3


precision1
precision2
precision3
recall1
recall2
recall3



TP=(TP1+TP2+TP3)/3
FP=(FP1+FP2+FP3)/3
TN=(TN1+TN2+TN3)/3
FN=(FN1+FN2+FN3)/3



type1error=(type1error1+type1error2+type1error3)/3
type2error=(type2error1+type2error2+type2error3)/3
type1error
type2error


accuracy=(accuracy1+accuracy2+accuracy3)/3
recall=(recall1+recall2+recall3)/3
precision=(precision1+precision2+precision3)/3
F_measure=(2*precision*recall)/(precision+recall)
accuracy


results=data.frame("GBN_CI-10cluster_3clusterclass",FP,TP,TN,FN,accuracy,recall,precision,F_measure,score)
setwd("C:/Users/Nastaran 2/Dropbox/BNolypen/3 cluster class/allcust_hour_TOU");
write.table(results, "C:/Users/Nastaran 2/Dropbox/BNolypen/3 cluster class/allcust_hour_TOU/results.txt", append=TRUE, sep="\t")


