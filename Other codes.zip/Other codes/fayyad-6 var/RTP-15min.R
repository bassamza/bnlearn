library(rJava)
library(bnlearn)
library(RBGL)
library(gRbase)
library(gRain)
library(RMySQL)
library(ROCR)
library(sampling)
library(xlsx)
library(arules)
library(RWeka)
library(caret) 



rm(list=ls()) 
cat("\014") 

#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

## check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "allcust_15min_rtp")
names(tmp)
# delete column read_time from this table
#drops <- c("read_time")
drops=c("read_time","monthofyear","day_week","isweekend")
allcust_15min <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
allcust_15min=allcust_15min[sample(nrow(allcust_15min)),];  


colnames(allcust_15min) <- c("Timeindex","Demand_t","Demand_t_1","Demand_t_2",
                            "Price","Temperature") 


#colnames(allcust_15min) <- c("Month","Hour","Demand_t","Demand_t_1","Demand_t_2",
#                           "Price","Temperature","Dayofweek","Isweekend") 


summary(allcust_15min$Demand_t)
plot(allcust_15min$Price,allcust_15min$Demand_t, xlab='RTP-hour price',ylab='RTP-hour Demand_t')


hist(allcust_15min[ ,6])


N=nrow(allcust_15min);
dumtrain=allcust_15min[1:(0.9*N),];
dumtest=allcust_15min[((0.9*N)+1):N,];


#define factors for some vectors
#Month<- factor(allcust_15min$Month)
Timeindex <- factor(allcust_15min$Timeindex)
#Dayofweek <- factor(allcust_15min$Dayofweek)
#Isweekend <- factor(allcust_15min$Isweekend)


### discretize class variable by k-means clustering 
Demand_t=arules::discretize(allcust_15min$Demand_t,'interval',categories=30);
summary(Demand_t)


#discretization by Rweka Fayyad and Irani MDL tool (supervised)
Demand_t_1=allcust_15min$Demand_t_1
Demand_t_2=allcust_15min$Demand_t_2
Price=allcust_15min$Price
Temperature=allcust_15min$Temperature
mydata=data.frame(Timeindex,Demand_t,Demand_t_1,Demand_t_2,Price,Temperature);
data <- RWeka::Discretize(Demand_t ~., data = mydata)
str(data)



#split data to train and test data sets
N=nrow(data);
train=data[1:(0.9*N),];
test=data[((0.9*N)+1):N,];


tan=tabu(train,score='bde',iss=50);
dsep(tan,"Price","Demand_t")



#plot  advanced BN using Rgraphviz
adjan=amat(tan)
mybn<-new("graphAM", adjMat=adjan, edgemode="directed")
plot(mybn,y="neato",attrs = list(node = list(fillcolor = "lightblue",fontsize=14,width=0.9),
                                 edge = list(arrowsize=0.25)))
#fit the network
tan.fit = bn.fit(tan, train, method = "mle")



midpoints <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(round(lower+(upper-lower)/2, dp))
}
# This function returns the midpoint of an interval x. gsub is a function that replaces some part of a string
# with a given new string.
#x <- "R Tutorial"
#gsub("ut","ot",x)
#[1] "R Totorial"
#the interval is treated as a string in R. the inner gsub in above function deletes () and [], actually replaces
#it with nothing. then the outer gsub replaces everything after comma with nothing just to grab the lower 
#limit


mymid=midpoints(levels(Demand_t))
mymid
probtable=((tan.fit$Demand_t)$prob)

#here we are assuming that the only parent for demand_t is the demand_t_1. If not we should change this line
myparent=test[1:30,]$Demand_t_1
myparent
mydist=probtable[,myparent]
mydist
mymean=mydist*mymid
mymean

pred=colSums(mymean)
pred

mysd=NULL  #before creating a new vector in a loop we need to initialize it.

for (i in  1:30) {
  mysd[i]=sqrt(sum(mydist[,i]*(mymid-pred[[i]])^2))
}

mysd




#calculate the mean of predicted value for train data
myparent=train$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
myres=as.data.frame(cbind(predmean, dumtrain$Demand_t))         
myres$error2=with(myres,(predmean-V2)^2)  #with is very useful function, it says to do all the calculations within a data frame
RMSE1=sqrt(sum(myres$error2)/nrow(myres))   


#calculate the mean of predicted value for test data
myparent=test$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
myres=as.data.frame(cbind(predmean, dumtest$Demand_t))         
myres$error2=with(myres,(predmean-V2)^2)  #with is very useful function, it says to do all the calculations within a data frame
RMSE2=sqrt(sum(myres$error2)/nrow(myres))


RMSE1
RMSE2



#1 st method to visualize the results
L=pred-1.96*mysd  #lower limit
U=pred+1.96*mysd
x=c(1:30)
plotCI(x,pred[1:30], ui=U[1:30], li=L[1:30],col="red",scol="blue",lwd=2,pch=21,xlab="Index",ylab="2sigma uncertainty interval for demand_t")
plotCI(x,dumtest$Demand_t[1:30], uiw=0,liw=0,col="black",add=TRUE,pch=15)
#plotCI function plots the confidence interval based on the mean value and lower and upper limits



#2 nd method to visualize the results
set.seed(1234)
x=c(1:30)
plot(pred[1:30],type='l',ylab="2sigma uncertainty interval for demand_t")
polygon(c(rev(x), x), c(rev(U[1:30]), L[1:30]), col = 'grey80', border = FALSE) #draws the shaded area- the rev is the reverse orde- we first draw the upper 
#band in reverse order and then the lower band
lines(pred[1:30],lwd=2)
lines(x, U[1:30], col="blue",lty=2)
lines(x,  L[1:30], col="blue",lty=2)
points(dumtest$Demand_t[1:30],col='red',pch=15)  



#exact inference with gRain (junction tree), 
jtree=compile(as.grain(tan.fit))   #export the network to grain
querygrain(jtree,nodes="Demand_t")$Demand_t #no evidence at all



#set the evidence for price
summary(data$Price)
levels=levels(data$Price)
state=levels[[2]]
state
jprop=setFinding(jtree,nodes=c("Price"),states=c(state))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)



#to get the lower limits of the levels of demnd_t
lowerpoint <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(lower)
}

#get the upper limit of the last interval of demand_t
y=levels(Demand_t)[length(levels(Demand_t))]
upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","",y )))


#all the breaking points to sketch the pdf of demand
breaks=c(lowerpoint(levels(Demand_t)),upper)


df <- data.frame(
  xmin = breaks[-length(breaks)],
  xmax = breaks[-1],
  ymin = 0,
  ymax = demanddis)


#plot histogram of demand after doing the inference
#this function from ggplot2 package plots incrementally-
ggplot(df, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax)) + 
  geom_rect(colour = 'gray',fill='blue4')+theme_bw() + 
  theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  xlab("Demand_t")+ylab("Density")



#to plot the density function of the demand after doing the inference i generate fake data set,I take the 
#midpoint of each interval and replicate it proportinal to the probability of that interval
fake=rep(mymid,demanddis*10000)
plot(density(fake),lwd=2,main="",ylab="Conditional distribution of Demand_t given price",xlab="Demand_t")




#set the evidence for Timeindex
jtree=compile(as.grain(tan.fit))   #export the network to grain
summary(data$Timeindex)
levels=levels(data$Timeindex)
state=levels[[40]]
state
jprop=setFinding(jtree,nodes=c("Timeindex"),states=c(state))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
demanddis

#plot histogram of demand after doing the inference
#this function from ggplot2 package plots incrementally-
ggplot(df, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax)) + 
  geom_rect(colour = 'gray',fill='blue4')+theme_bw() + 
  theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  xlab("Demand_t")+ylab("Density")

fake=rep(mymid,demanddis*10000)
plot(density(fake),lwd=2,main="",ylab="Conditional distribution of Demand_t given Timeindex=40",xlab="Demand_t",ylim=c(.006,.12))





#Approximate inference with bnleran package-rejection (logic) sampling
#generate random onservations for the desired node and get the distribution
levels(data$Demand_t)=c("Low","AVG","High");
summary(data$Price)
levels=levels(data$Price)
state=levels[[2]]
state


particles=cpdist(tan.fit,nodes="Demand_t",evidence=(Price==state & Hour== "18" & Month=="10"))
particles
prop.table(table(particles))


#get the probability of a specific event
cpquery(tan.fit,event=(Demand_t=="Low"),evidence=(Price==state & Hour== "18" & Month=="5"))










