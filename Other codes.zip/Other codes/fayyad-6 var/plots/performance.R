setwd("C:/Users/Nastaran 2/Dropbox/BN-new/fayyad/plots");



rm(list=ls()) 
cat("\014") 


data=read.table("performance.csv",header=T,sep=";")
data


mat=as.matrix(data[,2:6])
t(mat)

barplot(t(mat),
        names.arg=data$Model,col=c("darkblue","red","aquamarine1","burlywood1","coral1" ),
        legend = rownames(t(mat)), beside=TRUE,axis.lty=1,xpd=F,ylim=c(0,0.25),
        args.legend = list(x = "topleft"))


#legend=c("RTP-hour","TOU-hour","RTP-hour","TOU-15min","Households-hour")