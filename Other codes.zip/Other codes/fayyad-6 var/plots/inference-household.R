setwd("C:/Users/Nastaran 2/Dropbox/BN-new/fayyad/plots");



rm(list=ls()) 
cat("\014") 


data=read.table("household-inference.csv",header=T,sep=";")
data



barplot(data$high, ylab="P(Demand=high|Agg_demand,Month=5,Hour=18,C_ID=846)",xlab="Aggregate demand values",
        names.arg=data$Scenario,xpd=F,ylim=c(0,0.04),col=c("darkblue"),cex.lab=0.80,axis.lty=1)



