setwd("C:/Users/Nastaran 2/Dropbox/BN-new/fayyad/plots");



rm(list=ls()) 
cat("\014") 


data=read.table("RTP-hour-inference.csv",header=T,sep=";")
mat=as.matrix(data[,2:4])
mat

barplot(t(mat), ylab="Demand distribution",names.arg=data$Scenario,xlab="Different price values"
        ,col=c("darkblue","brown1","aquamarine2"),
        beside=TRUE,axis.lty=1,ylim=c(0,0.8),xpd=F)
