#these are accuracy
iss10=c(0.77,.63,.44,.25)
iss100= c(0.78,.66,.42,.27)
iss200=c(0.8,.62,.4,.25)
iss500=c(.83,.65,.47,.31)



plot(c(3,5,10,15),iss10,col="red",main= " ",ylab="Demand prediction accuracy by learnt BN model", xlab="No. of bins for demand",type="b",pch=14,lwd=2,ylim=c(.25,.85),xlim=c(2,16))
points(c(3,5,10,15),iss100,col="blue",main= " ",ylab=" ", xlab=" ",type="b",pch=15,lwd=2)
points(c(3,5,10,15),iss200,col="aquamarine4",main= " ",ylab=" ", xlab=" ",type="b",pch=16,lwd=2)
points(c(3,5,10,15),iss500,col="lightsalmon3",main= " ",ylab=" ", xlab=" ",type="b",pch=17,lwd=2)


legend('topright', c("iss=10","iss=100","iss=200","iss=500"), 
       lty=1, col=c('red','blue','aquamarine4','lightsalmon3'),lwd=2)



