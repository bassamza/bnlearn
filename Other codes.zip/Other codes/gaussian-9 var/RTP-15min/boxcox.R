
library(MASS)     # ... for Multivariate Normal Distribution
library(RMySQL)



rm(list=ls()) 
cat("\014") 


#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

## check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "allcust_15min_rtp")
names(tmp)
# delete column read_Timeindex from this table
#drops <- c("read_time","monthofyear","day_week","isweekend")
drops <- c("read_time")

allcust_15min <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
allcust_15min=allcust_15min[sample(nrow(allcust_15min)),];  


summary(allcust_15min);
colnames(allcust_15min) <- c("Month","Timeindex","Demand_t","Demand_t_1","Demand_t_2",
                            "Price","Temperature","Dayofweek","Isweekend")    


write.table(allcust_15min,"C:/Users/Nastaran 2/Dropbox/BN-new/gaussian/RTP-15min/rtp-15min.csv", sep=";",row.names = FALSE)

tmp=allcust_15min;
str(tmp)
summary(tmp$Demand_t)


tmp$Isweekend=tmp$Isweekend+1
tmp$Timeindex=as.numeric(tmp$Timeindex)
tmp$Month=as.numeric(tmp$Month)
tmp$Dayofweek=as.numeric(tmp$Dayofweek)
tmp$Isweekend=as.numeric(tmp$Isweekend)
str(tmp);
names(tmp)



b=boxcox(tmp$Month~1)              # Illustration of Log-Likelihood profile
lambda=b$x                       #get the lambda values
loglik=b$y                       #get the corresponding log likelihood values in the graph
bc=cbind(lambda, loglik)           #bind the two values together
bc2=as.data.frame(bc[order(-loglik),])  #sort based on loglik value to show its max value at the top
bestlambda=bc2$lambda[[1]]         #get the lambda corresponding to max log lik
Month=(tmp$Month)^bestlambda           #transform the variables by the selected lambda (just the first term)



b=boxcox(tmp$Dayofweek~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Dayofweek=(tmp$Dayofweek)^bestlambda




b=boxcox(tmp$Timeindex~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Timeindex=(tmp$Timeindex)^bestlambda



b=boxcox(tmp$Isweekend~1,lambda = seq(-5, 5, 1/10))              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Isweekend=(tmp$Isweekend)^bestlambda




b=boxcox(tmp$Demand_t~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t=(tmp$Demand_t)^bestlambda






b=boxcox(tmp$Demand_t~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t=(tmp$Demand_t)^bestlambda



b=boxcox(tmp$Demand_t_1~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t_1=(tmp$Demand_t_1)^bestlambda



b=boxcox(tmp$Demand_t_2~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t_2=(tmp$Demand_t_2)^bestlambda



b=boxcox(tmp$Price~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Price=(tmp$Price)^bestlambda

b=boxcox(tmp$Temperature~1,lambda = seq(-2, 5, 1/10))              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Temperature=(tmp$Temperature)^bestlambda


results=data.frame(Timeindex,Demand_t,Demand_t_1,Demand_t_2,Price,Temperature,Month,Dayofweek,Isweekend);
write.table(results,"C:/Users/Nastaran 2/Dropbox/BN-new/gaussian/RTP-15min/rtp-15min-boxcox.csv", sep=";",row.names = FALSE)
