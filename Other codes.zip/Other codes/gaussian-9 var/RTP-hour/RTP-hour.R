
#load all packages
library(Rgraphviz)
library(RBGL)
library(graph)

#I need to install these packages from tools/install packages when I install a new version of R/Rstudio
library(bnlearn)
library(gRbase)
library(gRain)
library(RMySQL)
library(ROCR)
library(sampling)
library(xlsx)
library(arules)
library(RWeka)
library(lattice)
library(forecast)
require(plotrix)  # draw confidence intervals



data=read.csv("C:/Users/Nastaran 2/Dropbox/BN-new/gaussian/RTP-hour/rtp-hour-boxcox.csv", header = TRUE, sep = ";")
hist(data$Demand_t)
summary(data$Demand_t)
str(data)
summary(data)



data$Isweekend=data$Isweekend+1
data$Timeindex=as.numeric(data$Timeindex)
data$Month=as.numeric(data$Month)
data$Dayofweek=as.numeric(data$Dayofweek)
data$Isweekend=as.numeric(data$Isweekend)



#split data to train and test data sets
N=nrow(data);
train=data[1:(0.9*N),];
test=data[((0.9*N)+1):N,];


#learning network structure
tan=tabu(train,score='bge',iss = 50); 
plot(tan)

mb=mb(tan,"Demand_t")
mb



#fit the network
tan.fit = bn.fit(tan, train, method = "mle")


coefficients(tan.fit$Demand_t)
mysd=sd(residuals(tan.fit$Demand_t))

#calculate the mean of predicted value for train data- fitted.value gives the mean for train data 
predmean=fitted.values(tan.fit$Demand_t)
myres=as.data.frame(cbind(predmean, train[, "Demand_t"]))         
myres$error=with(myres,((predmean-V2)/V2)^2)  #with is very useful function, it says to do all the calculations within a data frame
NRMSE1=sqrt(sum(myres$error)/nrow(myres))   #NRMSE is calculated by dividing each residual (error) by the observed value and summing the squares and then taking the mean and then square root



myres$error2=with(myres,(predmean-V2)^2)  #with is very useful function, it says to do all the calculations within a data frame
RMSE1=sqrt(sum(myres$error2)/nrow(myres))   #NRMSE is calculated by dividing each residual (error) by the observed value and summing the squares and then taking the mean and then square root


#calculate the mean of predicted value for test data
pred = predict(tan.fit,"Demand_t", test,method="parents")   #predict function by the parents methods just plugs in the parent values and so caculates the mean value  
myres=as.data.frame(cbind(pred, test[, "Demand_t"]))         
myres$error=with(myres,((pred-V2)/V2)^2)
NRMSE2=sqrt(sum(myres$error)/nrow(myres))


myres$error2=with(myres,((pred-V2))^2)
RMSE2=sqrt(sum(myres$error2)/nrow(myres))



NRMSE1
NRMSE2  #in general the relation between NRMSE 1(train) and NRMSE2 (test) depend on the complexity of the model-the error 
# complexity diagram- NRMSE1 is less than or equal to NRMSE 2


RMSE1
RMSE2




#1 st method to visualize the results
L=pred-1.96*mysd  #lower limit-2  sigma in normal distribution- by 2 sigma dist we cover %95 confidence interval
U=pred+1.96*mysd
x=c(1:30)
plotCI(x,pred[1:30], ui=U[1:30], li=L[1:30],col="red",scol="blue",lwd=2,pch=21,xlab="Index",ylab="%95 confidence interval for demand_t")
plotCI(x,test[1:30,"Demand_t"], uiw=0,liw=0,col="black",add=TRUE,pch=15)
#plotCI function plots the confidence interval based on the mean value and lower and upper limits




#2 nd method to visualize the results
set.seed(1234)
x=c(1:30)
plot(pred[1:30],type='l',ylab="%95 confidence interval for demand_t",ylim=c(1.045,1.1))
polygon(c(rev(x), x), c(rev(U[1:30]), L[1:30]), col = 'grey80', border = FALSE) #draws the shaded area- the rev is the reverse orde- we first draw the upper 
#band in reverse order and then the lower band
lines(pred[1:30],lwd=2)
lines(x, U[1:30], col="blue",lty=2)
lines(x,  L[1:30], col="blue",lty=2)
points(test[1:30, "Demand_t"],col='red',pch=15)  




#plot fuction opens a new window to plot, if we want to add to an existing plot we shouls use lines and points instead of new plots

bn.fit.histogram(tan.fit$Demand_t, density = TRUE, xlab = "Log Demand_t residuals",ylab="",
                 main = "Histogram of the Demand_t residuals")


bn.fit.qqplot(tan.fit$Demand_t, xlab = "Theoretical quantiles",
              ylab = "Sample quantiles", main = "Normal Q-Q Plot for Demand_t residuals")



bn.fit.xyplot(tan.fit$Demand_t, xlab = "Fitted values",
              ylab = "Residuals", main = "Residuals vs Fitted for Demand_t")


par(mfrow=c(1,1))
#plot  advanced BN using Rgraphviz
adjan=amat(tan)
mybn<-new("graphAM", adjMat=adjan, edgemode="directed")
plot(mybn,y="neato",attrs = list(node = list(fillcolor = "lightblue",fontsize=14,width=0.8),
                                 edge = list(arrowsize=0.25)))


dsep(tan,"Price","Demand_t")
dsep(tan,"Price","Demand_t","Month")

