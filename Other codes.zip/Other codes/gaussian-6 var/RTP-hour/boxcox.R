
library(MASS)     # ... for Multivariate Normal Distribution
library(RMySQL)



rm(list=ls()) 
cat("\014") 


#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

## check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "allcust_hour_rtp")
names(tmp)
# delete column read_Timeindex from this table
drops <- c("read_time","monthofyear","day_week","isweekend")
#drops <- c("read_time")

allcust_hour <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
allcust_hour=allcust_hour[sample(nrow(allcust_hour)),];  


summary(allcust_hour);
colnames(allcust_hour) <- c("Timeindex","Demand_t","Demand_t_1","Demand_t_2",
                            "Price","Temperature")    


write.table(allcust_hour,"C:/Users/Nastaran 2/Dropbox/BN-new/gaussian/RTP-hour/rtp-hour.csv", sep=";",row.names = FALSE)

tmp=allcust_hour;
str(tmp)
summary(tmp$Demand_t)
hist(tmp$Demand_t)


tmp$Timeindex=as.numeric(tmp$Timeindex)

str(tmp);
names(tmp)






b=boxcox(tmp$Timeindex~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Timeindex=(tmp$Timeindex)^bestlambda





b=boxcox(tmp$Demand_t~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t=(tmp$Demand_t)^bestlambda






b=boxcox(tmp$Demand_t~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t=(tmp$Demand_t)^bestlambda



b=boxcox(tmp$Demand_t_1~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t_1=(tmp$Demand_t_1)^bestlambda



b=boxcox(tmp$Demand_t_2~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Demand_t_2=(tmp$Demand_t_2)^bestlambda



b=boxcox(tmp$Price~1)              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Price=(tmp$Price)^bestlambda

b=boxcox(tmp$Temperature~1,lambda = seq(-2, 5, 1/10))              # Illustration of Log-Likelihood profile
lambda=b$x
loglik=b$y
bc=cbind(lambda, loglik)
bc2=as.data.frame(bc[order(-loglik),])
bestlambda=bc2$lambda[[1]]
Temperature=(tmp$Temperature)^bestlambda


results=data.frame(Timeindex,Demand_t,Demand_t_1,Demand_t_2,Price,Temperature);
write.table(results,"C:/Users/Nastaran 2/Dropbox/BN-new/gaussian/RTP-hour/rtp-hour-boxcox.csv", sep=";",row.names = FALSE)
