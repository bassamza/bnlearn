
#This lines of code are not well written and well documented. They may be editted
#and added to the end of RTP_hour.R script. 
#The second part of the code here is for generating fig 2 of the applied energy
#paper. Currently, it works with manusllay changing the discretization scheme and runnign 
#the code each time. But for a good code it should be rwritten in a loop



#get the lower limits of the levels of demand_t
lowerpoint <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(lower)
}


#get the upper limit of the last interval of demand_t
y=levels(Demand_t)[length(levels(Demand_t))]
upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","",y )))


#all the breaking points to sketch the pdf of demand
breaks=c(lowerpoint(levels(Demand_t)),upper)


#set the evidence for price
levels=levels(data$Price)
state=levels[[2]]
jprop=setFinding(jtree,nodes=c("Price"),states=c(state))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)



df <- data.frame(
  xmin = breaks[-length(breaks)],
  xmax = breaks[-1],
  ymin = 0,
  ymax = demanddis)


#plot histogram of demand after doing the inference
#this function from ggplot2 package plots incrementally-
ggplot(df, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax)) + 
  geom_rect(colour = 'gray',fill='blue4')+theme_bw() + 
  theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  xlab("Demand_t")+ylab("Density")


fake=rep(mymid,demanddis*10000)
plot(density(fake),lwd=2,main="",lty=1,ylab="P (demand_t | price > 48)",xlab="Demand_t",ylim=c(.0013,.03),cex.lab=1.3)



#---------------------------------------------------------------------------------------------------------------
#Here I want to show the effect of dicsretization scheme on the resulting pdf for demand.
#I should run the above code 3 times,each time switching the discretization between interval,frequency and cluster
#I save the results in fake1 and fake2 and fake3 and finally I plot them on the same graph
#---------------------------------------------------------------------------------------------------------------

#to plot the density function of the demand after doing the inference i generate fake data set,I take the 
#midpoint of each interval and replicate it proportinal to the probability of that interval
fake1=rep(mymid,demanddis*10000)
fake2=rep(mymid,demanddis*10000)
fake3=rep(mymid,demanddis*10000)


plot(density(fake1),lwd=2,main="",lty=1,ylab="P (demand_t | price > 48)",xlab="Demand_t",ylim=c(.0013,.03),cex.lab=1.3)
lines(density(fake2),lwd=2,col="red",lty=3)
lines(density(fake3),lwd=2,col="blue",lty=4)


legend('topright', c("30 cluster","30 equal width","30 equal frequency"), 
       lty=c(1,3,4), col=c('black','red','blue'),lwd=2)
