

# Electricity prediction using Bayesian networks
# 
# 
# @author: Nastaran Bassamzadeh
# nsbassamzadeh@gmail.com
# 
# This script is to predict the electricty demand for aggregate customers with 15 min
# time resolution. The original data is provided by Pacific Northwest National lab. The 
# prediction model is based on learing a Bayesian network and doing inference on it to 
# predict the marginal and conditional probability distribution of demand for all customers
# who receive real time price data from the utility company




library(bnlearn)  #Bayesian network modeling
library(gRain)    #Inference in Bayesian networks
library(RMySQL)   #Connect to the MySQL databases
library(arules)   #k-means clustering
library(RWeka)    #Fayyad and Irani discretization
library(RBGL)     #Plot advanced graph of the Bayesian network
library(plotrix)  # draw confidence intervals


#Clean the memory
rm(list=ls()) 
cat("\014") 


#-----------------------------------------------------------------------------------------------------------------

#Read and prepare data

#-----------------------------------------------------------------------------------------------------
#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

# check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "allcust_15min_rtp")
names(tmp)
# delete column read_time from this table
drops <- c("read_time")
allcust_15min <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
allcust_15min=allcust_15min[sample(nrow(allcust_15min)),];  


#Change the column names
colnames(allcust_15min) <- c("Month","Timeindex","Demand_t","Demand_t_1","Demand_t_2",
                          "Price","Temperature","Dayofweek","Isweekend") 

#Plot a single scatter plot
plot(allcust_15min$Price,allcust_15min$Demand_t, xlab='RTP-hour price',ylab='RTP-hour Demand_t')

#Plot histogram
hist(allcust_15min[ ,6])

#Store the observed demand value
observeddemand=NULL
for (i in 1:96){
  tmp2 <- subset(allcust_15min, Timeindex== i)
    observeddemand[i]=mean(tmp2$Demand_t)
}


#Store the actual values of data before discretization for future comparisons
N=nrow(allcust_15min);
dumtrain=allcust_15min[1:(0.9*N),];
dumtest=allcust_15min[((0.9*N)+1):N,];


#---------------------------------------------------------------------------------------------------------------

#Discretize variables (class variable: k-means, others: fayyad method)

#---------------------------------------------------------------------------------------------------------------
#define factors
Month<- factor(allcust_15min$Month)
Timeindex <- factor(allcust_15min$Timeindex)
Dayofweek <- factor(allcust_15min$Dayofweek)
Isweekend <- factor(allcust_15min$Isweekend)


# discretize class variable by k-means clustering 
Demand_t=arules::discretize(allcust_15min$Demand_t,'interval',categories=30);
summary(Demand_t)


#discretization by Rweka Fayyad and Irani MDL tool (supervised)
Demand_t_1=allcust_15min$Demand_t_1
Demand_t_2=allcust_15min$Demand_t_2
Price=allcust_15min$Price
Temperature=allcust_15min$Temperature
mydata=data.frame(Timeindex,Demand_t,Demand_t_1,Demand_t_2,Price,Temperature,Month,Dayofweek,Isweekend);
data <- RWeka::Discretize(Demand_t ~., data = mydata)


#-----------------------------------------------------------------------------------------------------------------

#Learn Bayesian network

#-----------------------------------------------------------------------------------------------------------------

#split data to train and test data sets
N=nrow(data);
train=data[1:(0.9*N),];
test=data[((0.9*N)+1):N,];

#learn the structure
tan=tabu(train,score='bde',iss=50);

#Check for conditional independencies
dsep(tan,"Price","Demand_t")

#fit the network
tan.fit = bn.fit(tan, train, method = "mle")


#plot  advanced BN using Rgraphviz
adjan=amat(tan)
mybn<-new("graphAM", adjMat=adjan, edgemode="directed")
plot(mybn,y="neato",attrs = list(node = list(fillcolor = "lightblue",fontsize=16,width=0.7),
                                 edge = list(arrowsize=0.25)))


#----------------------------------------------------------------------------------------------------------------

#Report the errors

#----------------------------------------------------------------------------------------------------------------
#Here we have discrete distribution, First I try to make analogy to continuous distribution and find the predicted
#values by the model.


midpoints <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(round(lower+(upper-lower)/2, dp))
}
# This function returns the midpoint of an interval x. gsub is a function that replaces some part of a string
# with a given new string.
#x <- "R Tutorial"
#gsub("ut","ot",x)
#[1] "R Totorial"
#the interval is treated as a string in R. the inner gsub in above function deletes () and [], actually replaces
#it with nothing. then the outer gsub replaces everything after comma with nothing just to grab the lower 
#limit

#getting the midpoint of demand_t and the learned conditional probability table for 
#node demand_t
mymid=midpoints(levels(Demand_t))
probtable=((tan.fit$Demand_t)$prob)


#here we are assuming that the only parent for demand_t is the demand_t_1.
#This needs to be verified for demand_t.
#calculate the RMSE for train data (residuals)
myparent=train$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
diff <- predmean - dumtrain$Demand_t
RMSE1=sqrt(sum(diff^2)/length(diff)) 
RMSE1


#calculate the RMSE for test data (generalization)
myparent=test$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
diff <- predmean - dumtest$Demand_t
RMSE2=sqrt(sum(diff^2)/length(diff)) 
RMSE2


#----------------------------------------------------------------------------------------------------------------

# Visualize the confidence interval of predictions for test data

#------------------------------------------------------------------------------------
#get the predicted value (mean) of demand_t for first 30 samples of the test data
myparent=test[1:50,]$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
pred=colSums(mymean)


#Calculate the stdev of demand_t for first 50 samples of test data

mysd=NULL  #before creating a new vector in a loop we need to initialize it.
for (i in  1:50) {
  mysd[i]=sqrt(sum(mydist[,i]*(mymid-pred[[i]])^2))
}



#plot the bar confidence intervals for 30 samples from test data
L=pred-1.96*mysd  #lower limit
U=pred+1.96*mysd
x=c(1:50)
plotCI(x,pred[1:50], ui=U[1:50], li=L[1:50],col="black",scol="blue",lwd=2,pch=4,xlab="Index of test cases",ylab="2 sigma uncertainty interval in predicting demand_t",cex.lab=1.2)
plotCI(x,dumtest$Demand_t[1:50], uiw=0,liw=0,col="red",add=TRUE,pch=15)
#plotCI function plots the confidence interval based on the mean value and lower and upper limits



#plot the shaded confidence intervals for 30 samples from test data
set.seed(1234)
x=c(1:50)
plot(pred[1:50],type='l',ylab="2sigma uncertainty interval for demand_t")
polygon(c(rev(x), x), c(rev(U[1:50]), L[1:50]), col = 'grey80', border = FALSE) 
#draws the shaded area- the rev is the reverse orde- we first draw the upper 
#band in reverse order and then the lower band
lines(pred[1:50],lwd=2)
lines(x, U[1:50], col="blue",lty=2)
lines(x,  L[1:50], col="blue",lty=2)
points(dumtest$Demand_t[1:50],col='red',pch=15)  



#-----------------------------------------------------------------------------------------------------------------

#Doing inference using the learned model

#----------------------------------------------------------------------------------------------------------------

#exact inference with gRain (junction tree), 
jtree=compile(as.grain(tan.fit))   #export the network to grain
querygrain(jtree,nodes="Demand_t")$Demand_t #no evidence at all



#-----------------------------------------------------------------------------------------------------------------

#Comparing the timely variations of predicted mean and observed mean and predicted meadian

#----------------------------------------------------------------------------------------------------------------
levels1=levels(data$Timeindex)
mymean=NULL
mystd=NULL
mymedian=NULL
mymode=NULL

for (i in 1:96){
  jprop=setFinding(jtree,nodes=c("Timeindex"),states=c(levels1[i]))
  demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)  
  realizations=rep(mymid,demanddis*10000)
  
  mymean[i]=mean(realizations)  
  mystd[i]=sqrt(var(realizations))
  mymode[i] <- names(sort(-table(realizations)))[1]
  mymedian[i]=median(realizations)
  
}


x=c(1:96)
plot(mymean,type='l', lty=2,ylim=c(5,20),xaxt="n",ylab="Electricity consumption",cex.lab=1.2,xlab="Time(h)")
lines(x,mymean,xlab="Time(h)",col='black',lwd=2,type='l',xaxt="n",lty=6)
axis(1, at = seq(1, 96, by = 8), las=2)
lines(x,observeddemand,pch=4,col='red',lwd=2,lty=4)
lines(x,mymedian,col='blue',lwd=2,lty=1)


legend('topright', c("Predicted mean","Observed mean","Predicted median"), 
       lty=c(6,4,1), col=c('black','red','blue'),lwd=2)



