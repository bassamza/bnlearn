
# Electricity prediction using Bayesian networks
# 
# 
# @author: Nastaran Bassamzadeh
# nsbassamzadeh@gmail.com
# 
# This script is to predict the electricty demand for each individaual customer with an hourly
# time resolution. The original data is provided by Pacific Northwest National lab. The 
# prediction model is based on learing a Bayesian network and doing inference on it to 
# predict the marginal and conditional probability distribution of demand for each customer
# who receive real time price data from the utility company.




library(bnlearn)  #Bayesian network modeling
library(gRain)    #Inference in Bayesian networks
library(RMySQL)   #Connect to the MySQL databases
library(arules)   #k-means clustering
library(RWeka)    #Fayyad and Irani discretization
library(RBGL)     #Plot advanced graph of the Bayesian network
library(plotrix)  # draw confidence intervals



#Clean the memory
rm(list=ls()) 
cat("\014") 


#-------------------------------------------------------------------------------------------

#Read and prepare data

#-------------------------------------------------------------------------------------------

#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

## check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
#import the desired table from database
tmp <- dbReadTable(con, "eachRTPcust_hour")
# delete column read_time from this table
drops <- c("read_time","contract_type_code","usage_model_kwh_per_hdh")
eachRTPcust_hour <- (tmp[,!(names(tmp) %in% drops)])
# shuffle rows randomly
eachRTPcust_hour=eachRTPcust_hour[sample(nrow(eachRTPcust_hour)),];  


summary(eachRTPcust_hour);
str(eachRTPcust_hour)

#Change the column names
colnames(eachRTPcust_hour) <- c("C_ID","Month","Hour","Demand_t","Demand_t_1","Demand_t_2",
                                "Price","Temperature","Contract","Dayofweek","Isweekend","use_avg","use_var","Agg_Demand") 


#Plot histogram
hist(eachRTPcust_hour[ ,6])


#Plot paired scatter plots
pairs(~Demand_t+Price+Temperature+Hour,data = eachRTPcust_hour[1:100,],
      main = "Scatterplot Matrix")


#Store the actual values of data before discretization for future comparisons
N=nrow(eachRTPcust_hour);
dumtrain=eachRTPcust_hour[1:(0.9*N),];
dumtest=eachRTPcust_hour[((0.9*N)+1):N,];


#---------------------------------------------------------------------------------------------------------------

#Discretize variables (class variable: k-means, others: fayyad method)

#-----------------------------------------------------------------------------------------------------------------
#transform these two columns to numeric type rather than integer
eachRTPcust_hour$use_avg <- as.numeric(eachRTPcust_hour$use_avg);
eachRTPcust_hour$use_var <- as.numeric(eachRTPcust_hour$use_var);

#define factors for some vectors
C_ID<- factor(eachRTPcust_hour$C_ID)
Month<- factor(eachRTPcust_hour$Month)
Hour <- factor(eachRTPcust_hour$Hour)
Dayofweek <- factor(eachRTPcust_hour$Dayofweek)
Isweekend <- factor(eachRTPcust_hour$Isweekend)


# discretize class variable by k-means clustering 
Demand_t=arules::discretize(eachRTPcust_hour$Demand_t,'interval',categories=30);
summary(Demand_t)


#Discretization by Rweka Fayyad and Irani MDL tool (supervised)
Demand_t_1=eachRTPcust_hour$Demand_t_1
Demand_t_2=eachRTPcust_hour$Demand_t_2
Price=eachRTPcust_hour$Price
Temperature=eachRTPcust_hour$Temperature
Agg_Demand=eachRTPcust_hour$Agg_Demand
use_avg=eachRTPcust_hour$use_avg
use_var=eachRTPcust_hour$use_var

mydata=data.frame(C_ID,Month,Hour,Demand_t,Demand_t_1,Demand_t_2,Agg_Demand,Price,Temperature,use_avg,use_var,Dayofweek,Isweekend);
data <- RWeka::Discretize(Demand_t ~., data = mydata)


#-----------------------------------------------------------------------------------------------------------------

#Learn Bayesian network

#----------------------------------------------------------------------------------------------------------------

#split data to train and test data sets
N=nrow(data);
train=data[1:(0.9*N),];
test=data[((0.9*N)+1):N,];

#learn the structure
tan=tabu(train,score='bde',iss=5000);

#Check for conditional independencies
dsep(tan,"Price","Demand_t","Month")

#fit the network
tan.fit = bn.fit(tan, train, method = "mle")

#plot  advanced BN using Rgraphviz
adjan=amat(tan)
mybn<-new("graphAM", adjMat=adjan, edgemode="directed")
plot(mybn,y="neato",attrs = list(node = list(fillcolor = "lightblue",fontsize=16,width=0.65),
                                 edge = list(arrowsize=0.25)))

#----------------------------------------------------------------------------------------------------------------

#Report the errors

#----------------------------------------------------------------------------------------------------------------
#Here we have discrete distribution, First I try to make analogy to continuous distribution and find the predicted
#values by the model.

midpoints <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(round(lower+(upper-lower)/2, dp))
}
# This function returns the midpoint of an interval x. gsub is a function that replaces some part of a string
# with a given new string.
#x <- "R Tutorial"
#gsub("ut","ot",x)
#[1] "R Totorial"
#the interval is treated as a string in R. the inner gsub in above function deletes () and [], actually replaces
#it with nothing. then the outer gsub replaces everything after comma with nothing just to grab the lower 
#limit


#getting the midpoint of demand_t and the learned conditional probability table for 
#node demand_t
mymid=midpoints(levels(Demand_t))
probtable=((tan.fit$Demand_t)$prob)


myparent=NULL
mydist=NULL
pred=NULL
#calculate the RMSE for train data (residuals)
#be carefule: in 2nd line the order of the parents should be checked- if in the probtable demanad_T_1
#is in the 3rd dimension this should be modified
for (i in 1:dim(train)[1]){
  myparent=train[i,c("use_avg","Demand_t_1")]
  mydist=probtable[ ,myparent$Demand_t_1,myparent$use_avg]
  pred[i]=sum(mydist*mymid)
}

RMSE1=sqrt(sum((pred-dumtrain$Demand_t)^2)/nrow(train))
RMSE1



myparent=NULL
mydist=NULL
pred=NULL
#calculate the mean of predicted value for test data
for (i in 1:nrow(test)){
  myparent=test[i,c("use_avg","Demand_t_1")]
  mydist=probtable[ ,myparent$Demand_t_1,myparent$use_avg]
  pred[i]=sum(mydist*mymid)
}

pred[is.na(pred)]=0  #this line is because I had one line of NA in pred vector and I replaced it with 0
summary(pred)

RMSE2=sqrt(sum((pred-dumtest$Demand_t)^2)/nrow(test))
RMSE2



#----------------------------------------------------------------------------------------------------------------

# Visualize the confidence interval of predictions for test data

#----------------------------------------------------------------------------------------------

myparent=NULL
mydist=NULL
pred=NULL
mysd=NULL

#get the predicted value (mean) of demand_t for first 50 samples of the test data
#here we should modify the parents based on the learnt network
#be carefule: in 2nd line the order of the parents should be checked- if in the probtable demanad_T_1
#is in the 3rd dimension this should be modified
for (i in 1:50){
  myparent=test[i,c("use_avg","Demand_t_1")]
  mydist=probtable[ ,myparent$Demand_t_1,myparent$use_avg]
  pred[i]=sum(mydist*mymid)
  mysd[i]=sqrt(sum(mydist*(mymid-pred[i])^2)) #the stdev is not constant
}


#plot the bar confidence intervals for 50 samples from test data
L=pred-1.96*mysd  #lower limit
U=pred+1.96*mysd
x=c(1:50)
plotCI(x,pred[1:50], ui=U[1:50], li=L[1:50],col="black",lwd=2,pch=4,xlab="Index of test cases",ylab="2sigma uncertainty interval in predicting demand_t")
plotCI(x,dumtest$Demand_t[1:50], uiw=0,liw=0,col="red",add=TRUE,pch=15)
#plotCI function plots the confidence interval based on the mean value and lower and upper limits



#plot the shaded confidence intervals for 50 samples from test data
set.seed(1234)
x=c(1:50)
plot(pred[1:50],type='l',ylab="2 sigma uncertainty interval in predicting demand_t",ylim=c(-2,8),cex.lab=1.2,xlab="Index of test cases")
polygon(c(rev(x), x), c(rev(U[1:50]), L[1:50]), col = 'grey80', border = FALSE) 
#draws the shaded area- the rev is the reverse orde- we first draw the upper 
#band in reverse order and then the lower band
lines(pred[1:50],lwd=2)
lines(x, U[1:50], col="blue",lty=2)
lines(x,  L[1:50], col="blue",lty=2)
points(dumtest$Demand_t[1:50],col='red',pch=15)  


#-----------------------------------------------------------------------------------------------------------------

#Doing inference using the learned model

#----------------------------------------------------------------------------------------------------------------

#exact inference with gRain (junction tree), 
jtree=compile(as.grain(tan.fit))   #export the network to grain
querygrain(jtree,nodes="Demand_t")$Demand_t #no evidence at all


#------------------------------------------------------------------------------------------------

# Plot effect of price variations on demand PDF for a particular customer at a specific time

#------------------------------------------------------------------------------------------------
#set the evidence for price at a fixed time index for a particular customer
summary(data$Price)
levels=levels(data$Price)
levels2=levels(data$C_ID)


#to plot the density function of the demand after doing the inference i generate fake data set,I take the 
#midpoint of each interval and replicate it proportinal to the probability of that interval

#case1
state1=levels[[3]]
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(state1,"10","671"))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake1=rep(mymid,demanddis*10000)


#case 2
state2=levels[[7]]
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(state2,"10","671"))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake2=rep(mymid,demanddis*10000)


#case3
state3=levels[[9]]
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(state3,"10","671"))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake3=rep(mymid,demanddis*10000)


plot(density(fake1),lwd=2,lty=1,main="",ylab="P(demand_t | timeindex=10, C_ID=671, price)",xlab="Demand_t",ylim=c(0.035,.85),cex.lab=1.2)
lines(density(fake2),lwd=2,lty=3,col="red")
lines(density(fake3),lwd=2,lty=4,col="blue")
legend('topright', c("20.6 < price < 35.6","51 < price < 59.9","83.8 < price"), 
       lty=c(1,3,4), col=c('black','red','blue'),lwd=2)


#-----------------------------------------------------------------------------------------------------------------

# Plot demand PDF for different customers at a specific time and price

#----------------------------------------------------------------------------------------------------------------

#set the evidence for Customer ID
levels1=levels(data$Price)
pricevalue=levels1[[7]]
levels2=levels(data$C_ID)


#case1
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(pricevalue,"10",levels2[[10]]))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake1=rep(mymid,demanddis*10000)

#case 2
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(pricevalue,"10",levels2[[15]]))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake2=rep(mymid,demanddis*10000)

#case3
jprop=setFinding(jtree,nodes=c("Price","Timeindex","C_ID"),states=c(pricevalue,"10",levels2[[20]]))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)
fake3=rep(mymid,demanddis*10000)


plot(density(fake1),lwd=2,lty=1,main="",ylab="P(demand_t | timeindex=10, 51 < price < 59.9, C_ID)",xlab="Demand_t",ylim=c(0.032,.7),cex.lab=.9)
lines(density(fake2),lwd=2,lty=3,col="red")
lines(density(fake3),lwd=2,lty=4,col="blue")
legend('topright', c("C_ID=707","C_ID=855","C_ID=867"), 
       lty=c(1,3,4), col=c('black','red','blue'),lwd=2)


#-----------------------------------------------------------------------------------------------------------------

#Plot hourly variations of expected value of demand for one  customer at 4 different price ranges.

#----------------------------------------------------------------------------------------------------------------
levels1=levels(data$Price)
levels2=levels(data$C_ID)
levels3=levels(data$Hour)

mymean=matrix(data=NA, nrow=24, ncol=length(levels1))
levels2[[3]]

for (j in 1:length(levels1)){
  for (i in 1:24){
    jprop=setFinding(jtree,nodes=c("C_ID","Price","Hour"),states=c(levels2[[3]],levels1[[j]],levels3[i]))
    demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)  
    realizations=rep(mymid,demanddis*10000)
    mymean[i,j]=mean(realizations)
  }
}


x=c(1:24)
plot(x,mymean[,1],ylab="E[demand_t | C_ID=680]",cex.lab=1.2,xlab="Time(h)",pch=4,col='red',lwd=2,type='l',ylim=c(0.1,2.5),xaxt="n")
axis(1, at = seq(1, 24, by = 2), las=2)
lines(x,mymean[,3],pch=4,col='blue',lwd=2,lty=2)
lines(x,mymean[,5],pch=15,col='black',lwd=2,lty=12)
lines(x,mymean[,7],pch=10,col='darkorange2',lwd=2,lty=10)
legend('topright', c("price < 3.6","20.6 < price < 35.7","48.2 < price<50.9","51 < price<59.9"), 
       lty=c(1,2,12,10), col=c('red','blue','black','darkorange2'),lwd=2)


#-----------------------------------------------------------------------------------------------------------------

#Plot hourly variations of expected value of demand for 9 different customers given a specific price.

#----------------------------------------------------------------------------------------------------------------
levels1=levels(data$C_ID)
levels2=levels(data$Price)
levels3=levels(data$Hour)

mymean=matrix(data=NA, nrow=24, ncol=length(levels1))


for (j in 1:length(levels1)){
  for (i in 1:24){
    jprop=setFinding(jtree,nodes=c("C_ID","Price","Hour"),states=c(levels1[[j]],levels2[[3]],levels3[i]))
    demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)  
    realizations=rep(mymid,demanddis*10000)
    mymean[i,j]=mean(realizations)
  }
}


x=c(1:24)
plot(x,mymean[,1],ylab="E[demand | 20.6<price<35.7]",lty=21,cex.lab=1.2,xlab="Time(h)",col='red',lwd=2,type='l',ylim=c(0.1,2.5),xaxt="n")
axis(1, at = seq(1, 24, by = 2), las=2)
lines(x,mymean[,3],pch=4,col='blue',lwd=2,lty=2)
lines(x,mymean[,5],col='black',lwd=2,lty=5)
lines(x,mymean[,9],col='darkorange2',lwd=2,lty=6)
lines(x,mymean[,12],col='chocolate2',lwd=2,lty=9)
lines(x,mymean[,15],col='cyan3',lwd=2,lty=10)
lines(x,mymean[,18],col='darkorchid3',lwd=2,lty=13)
lines(x,mymean[,21],col='goldenrod',lwd=2,lty=14)
lines(x,mymean[,24],col='olivedrab3',lwd=2,lty=17)
legend('topright', "Various customers" ,lwd=2)



#-----------------------------------------------------------------------------------------------------------------

# Sensitivity analysis- Run multiple inference queries with different evidences and see the changes
# in the histogram of demand.

#----------------------------------------------------------------------------------------------------------------
#to get the lower limits of the levels of demnd_t
lowerpoint <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(lower)
}


#get the upper limit of the last interval of demand_t
y=levels(Demand_t)[length(levels(Demand_t))]
upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","",y )))


#all the breaking points to sketch the histogram of demand
breaks=c(lowerpoint(levels(Demand_t)),upper)



#set the evidences
mymid=midpoints(levels(Demand_t))
levels1=levels(data$Price)
levels3=levels(data$Temperature)
levels6=levels(data$Agg_Demand)



jprop=setFinding(jtree,nodes=c("C_ID","Hour"),states=c("900","18"))
demanddis=(querygrain(jprop,nodes="Demand_t")$Demand_t)

df <- data.frame(
  xmin = breaks[-length(breaks)],
  xmax = breaks[-1],
  ymin = 0,
  ymax = demanddis)


#plot histogram of demand after doing the inference
#this function from ggplot2 package plots incrementally
ggplot(df, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax)) + 
  geom_rect(colour = 'gray',fill='blue4')+theme_bw() + 
  theme(panel.border = element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  xlab("Demand_t")+ylab("Density")


#These are other queries that maybe replace the code on line 440 (jprop) and we can see
# the corresponding histogram
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Isweekend"),states=c("900","18","1"))
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Price"),states=c("900","18",levels1[[2]]))
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Temperature"),states=c("900","18",levels3[[1]]))
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Agg_Demand"),states=c("900","18",levels6[[3]]))
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Month"),states=c("900","18","12"))
jprop=setFinding(jtree,nodes=c("C_ID","Hour","Dayofweek"),states=c("900","18","4"))

