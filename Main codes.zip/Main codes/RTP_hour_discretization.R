
# MODEL SELECTION FOR DISCRETIZNG THE DEMAND_T VARIABLE
# (FOR DEMAND PREDICTION OF AGGREGATE CUSTOMER WITH HOURLY TIME RESOLUTION)
# 
# 
# @author: Nastaran Bassamzadeh
# nsbassamzadeh@gmail.com
# 
# This script is to find the optimal setting for discretizing the demand_t variable
# In fact, we are doing model selection, by finding the best method (clster vs interval
# vs frequency) and best number of bins for discretizing.



library(bnlearn)  #Bayesian network modeling
library(gRain)    #Inference in Bayesian networks
library(RMySQL)   #Connect to the MySQL databases
library(arules)   #k-means clustering
library(RWeka)    #Fayyad and Irani discretization
library(RBGL)     #Plot advanced graph of the Bayesian network
library(plotrix)  # draw confidence intervals


#Clean the memory
rm(list=ls()) 
cat("\014") 


#-----------------------------------------------------------------------------------------------------------------

#Read and prepare data

#-----------------------------------------------------------------------------------

#disconnect all the connection to MySQL server
all_cons <- dbListConnections(MySQL())
for(con in all_cons)
  +  dbDisconnect(con)

# check all connections have been closed
dbListConnections(MySQL())
list()

#connect to the database  
con <- dbConnect(MySQL(), user="root", password="1234",dbname = "olypen", host ="localhost")
tmp <- dbReadTable(con, "allcust_hour_rtp")
drops <- c("read_time")
allcust_hour <- (tmp[,!(names(tmp) %in% drops)])
allcust_hour=allcust_hour[sample(nrow(allcust_hour)),];  
colnames(allcust_hour) <- c("Month","Timeindex","Demand_t","Demand_t_1","Demand_t_2",
                            "Price","Temperature","Dayofweek","Isweekend") 

allcust_hour <- subset(allcust_hour, 10 < Demand_t & Demand_t< 105)


N=nrow(allcust_hour);
dumtrain=allcust_hour[1:(0.9*N),];
dumtest=allcust_hour[((0.9*N)+1):N,];

#---------------------------------------------------------------------------------------------------------------

#Discretize variables (class variable: k-means, others: fayyad method)

#-------------------------------------------------------------------------------
#define factors for some vectors
Month<- factor(allcust_hour$Month)
Timeindex <- factor(allcust_hour$Timeindex)
Dayofweek <- factor(allcust_hour$Dayofweek)
Isweekend <- factor(allcust_hour$Isweekend)


midpoints <- function(x, dp=2){
  lower <- as.numeric(gsub(",.*","",gsub("\\(|\\[|\\)|\\]","", x)))
  upper <- as.numeric(gsub(".*,","",gsub("\\(|\\[|\\)|\\]","", x)))
  return(round(lower+(upper-lower)/2, dp))
}


mymethods=c("Cluster","Interval","frequency")
myRMSE=matrix(data=NA, nrow=6, ncol=length(seq(5,60,5)))


#---------------------------------------------------------------------------------------------------------------

#The main loop which itterates over the discretization method and number of bins

#--------------------------------------------------------------------------------------
for ( i in 1:3){
  for (j in seq(5,60,5)){

# discretize class variable 
Demand_t=arules::discretize(allcust_hour$Demand_t,mymethods[i],categories=j);


#discretization by Rweka Fayyad and Irani MDL tool (supervised)
Demand_t_1=allcust_hour$Demand_t_1
Demand_t_2=allcust_hour$Demand_t_2
Price=allcust_hour$Price
Temperature=allcust_hour$Temperature
mydata=data.frame(Timeindex,Demand_t,Demand_t_1,Demand_t_2,Price,Temperature,Month,Dayofweek,Isweekend);
data <- RWeka::Discretize(Demand_t ~., data = mydata)

#learn Bayesian network
N=nrow(data);
train=data[1:(0.9*N),];
test=data[((0.9*N)+1):N,];

tan=tabu(train,score='bde',iss=50);
tan.fit = bn.fit(tan, train, method = "mle")

mymid=midpoints(levels(Demand_t))
probtable=((tan.fit$Demand_t)$prob)


#calculate the mean of predicted value for train data
myparent=train$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
diff <- predmean - dumtrain$Demand_t
RMSE1=sqrt(sum(diff^2)/length(diff)) 
RMSE1

#calculate the mean of predicted value for test data
myparent=test$Demand_t_1
mydist=probtable[,myparent]
mymean=mydist*mymid
predmean=colSums(mymean)
diff <- predmean - dumtest$Demand_t
RMSE2=sqrt(sum(diff^2)/length(diff)) 
RMSE2

myRMSE[i,j/5]=RMSE1   #fill the matrix by rows (first three rows are train RMSE)
myRMSE[i+3,j/5]=RMSE2  #second three rows are test RMSE
  }
}

#---------------------------------------------------------------------------------------------------------------

# Plot the results

#-----------------------------------------------------------------------------------
x=seq(5,60,5)

#these rows correspond to test results
plot(x,myRMSE[4,],col="red",main= " ",ylab="RMSE in predicting demand_t", xlab="Number of bins",type="b",pch=16,ylim=c(7.8,9.1),lwd=2,cex.lab=1.1)
points(x,myRMSE[5,],col="blue",main= " ",ylab=" ", xlab=" ",type="b",pch=17,lwd=2)
points(x,myRMSE[6,],col="darkgoldenrod",main= " ",ylab=" ", xlab=" ",type="b",pch=8,lwd=2)
abline(v=35,lwd=2,lty=3,col='black')


legend('topright', c("Cluster","Interval","Frequency"), 
       lty=1, col=c('red','blue','darkgoldenrod'),pch=c(16,17,8),lwd=2)



