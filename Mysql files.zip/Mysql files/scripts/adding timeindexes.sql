SELECT * FROM olypen.invensys_meter;
UPDATE olypen.invensys_meter SET monthofyear = month(read_time);
UPDATE olypen.invensys_meter SET day_week = dayofweek(read_time);
UPDATE olypen.invensys_meter SET timeindex = (time_to_sec(timediff(time(read_time),'00:00:00'))/60)/15+1;


UPDATE olypen.invensys_meter 
SET isweekend= 1
where invensys_meter.day_week=1 or 7;

