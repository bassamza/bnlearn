
# the initial tables that I use from raw sql files are as follows:
# prices, invensys-weatehr,invensys_meter,customer.
# I deleted the data for four customers in Oregon state and so I am keeping the data for only three zip codes: 98362,98363 (in port angeles, WA)
#and 98382 (in sequim wa). 


#Day of week: sunday=1,Monday =2 ,...
#number of customers in each category (after deleting those 4 customers in oregon state):
#fixed:28,RTP:27,TOU:27,CTRL:25  (the consumption data for CTRL customers is in the final table but their price and temp and .. are not known,
#so i deleted them in mynonullpricetemp file).
#57 customers in port angeles, 50 in sequim (incuding CTRL)

#usage_model_kwh_base:fixed energy term of usage model
#usage_model_kwh_per_hdh:heating energy term of usage model
#usage_model_kwh_stdev:stdev of usage data

#meter_reaeding:watt
#price: $/Mwh
#temperature:F

#month 1 is Jan, and Winter starts from Jan.



# add RTP price columnallcust_hour
update final
left join prices
ON final.read_time = prices.posttime
set final.price=prices.rtp_price
where final.contract_type_code='RTP';

select * from olypen.final
group by contract_type_code;

# assign the prices for TOU and fixed prices based on the report of the peninsula project
update final
set price=85
where contract_type_code='FIXED' and date(read_time) between '2006-01-01' and '2006-03-31' ;

update final
set price=81
where contract_type_code='FIXED' and date(read_time) >= '2006-04-01' ;


update final
set price=41.19
where final.contract_type_code='TOU' and (date(read_time) between '2006-04-01' and '2006-07-24' or date(read_time) between '2006-10-01' and '2007-03-31')
and (hour(read_time) between 9 and 17 or hour(read_time) between 21 and 23 or hour(read_time) between 0 and 5) ;


update final
set price=121.5
where contract_type_code='TOU' and (date(read_time) between '2006-04-01' and '2006-07-24' or date(read_time) between '2006-10-01' and '2007-03-31')
and (hour(read_time) between 6 and 8 or hour(read_time) between 18 and 20);


update final
set price=50
where contract_type_code='TOU' and date(read_time) between '2006-07-25' and '2006-09-30' 
and (hour(read_time) between 21 and 23 or hour(read_time) between 0 and 14);


update final
set price=135
where contract_type_code='TOU' and date(read_time) between '2006-07-25' and '2006-09-30' 
and hour(read_time) between 15 and 20 ;


update final
set price=350
where contract_type_code='TOU' and date(read_time) ='2006-11-01' 
and hour(read_time) between 2 and 5 ;

# add weather column based on myweather table. myweather is create based on invensys-weather data.
update final
left join myweather
ON final.read_time =  myweather.read_time and final.zipcode= myweather.zipcode
set final.Temperature= myweather.temperature;


delete from olypen.final
where meter_reading=0 or price <= 0 or price >= 350 ;






