
#final table has all the fields I need except meter_reading_t_1 and _t_2 and It has lots of nulls in price and temperature. almost all 
#of teh nulls are due to customers with no data of their city. originally contarct_type has CTRL and null values as well. but if we delete these two
#categories then there is no null in other fields as well.

#mynonullpricetemp is the same as nonullpricetemp in which unwanted columns such as city, zipcode, .. are deleted. In mynonullpricetemp there is no null
#value at all (not in price, not in temp and nowhere else). 


#mynonullpricetemp has fine resolutions for customers and time. It is equivalent to eachcustomer-15 min. In this script i:
#a) create columns meter_reading(t-1) and meter_reading(t-2) for mynonullpricetemp
#b) create three more tables withvarious resolutions for customers and time(each custoemr vs all customers and 15 min vs 1 hour)
# the name of created tables is allcust_15min, allcust_hour,eachcust_hour



 
# create meter_reading_t_1 and meter_reading_t_2 columns. First create a temporary table and then left join it to teh original table when time is
#15 min back.  
CREATE TABLE tmp LIKE mynonullpricetemp;
#delete unwanted columns manually at this stage
INSERT into tmp (customer_id,read_time,meter_reading)
 SELECT customer_id,read_time,meter_reading FROM mynonullpricetemp;


update mynonullpricetemp 
left join tmp
on mynonullpricetemp.customer_id=tmp.customer_id and subtime(mynonullpricetemp.read_time,'00:15:00')=tmp.read_time  
set mynonullpricetemp.meter_reading_t_1=tmp.meter_reading;


update mynonullpricetemp
left join tmp
on mynonullpricetemp.customer_id=tmp.customer_id and subtime(mynonullpricetemp.read_time,'00:30:00')=tmp.read_time
set mynonullpricetemp.meter_reading_t_2=tmp.meter_reading;


# createtable eachcust_hour, the time resolution is hour. 
create table eachcust_hour as(
select customer_id,date(read_time) as date_id ,hour(read_time) as hourindex,sum(meter_reading) as meter_reading ,monthofyear,day_week,isweekend,usage_model_kwh_base,usage_model_kwh_per_hdh,
usage_model_kwh_stdev,contract_type_code,avg(price) as price, avg(temperature) as temperature
from mynonullpricetemp
group by customer_id,date(read_time),hour(read_time));

#modify table eachcust_hour so that we can generate meter_reading_t_1 and _t_2 columns. 
ALTER TABLE eachcust_hour ADD COLUMN meter_reading_t_1 double DEFAULT null;
ALTER TABLE eachcust_hour ADD COLUMN meter_reading_t_2 double DEFAULT null;
Alter table  eachcust_hour add column myhour time default null after hourindex;
Alter table  eachcust_hour add column read_time datetime default null after myhour;

# we need to convert the hour index to a time field, ex 15 to '15:00:00' and then concatenate the date and time field to make a timedate field.
# this way we can generete _t_1 and T_2 fields as before.
update  eachcust_hour set myhour=SEC_TO_TIME(hourindex*60*60);
update  eachcust_hour set read_time=concat(date_id,' ',myhour);

Alter table eachcust_hour drop date_id,drop myhour;

#create  _t_1 and T_2 fields for eachcust_hour.
CREATE TABLE tmp4 LIKE eachcust_hour;
ALTER TABLE tmp4 drop monthofyear, drop hourindex,drop day_week,drop isweekend,drop usage_model_kwh_base,drop usage_model_kwh_per_hdh,drop usage_model_kwh_stdev,drop contract_type_code,drop price,drop temperature;

INSERT into tmp4 (customer_id,read_time,meter_reading)
SELECT customer_id,read_time,meter_reading FROM eachcust_hour;

update eachcust_hour
left join tmp4
on eachcust_hour.customer_id=tmp4.customer_id and subtime(eachcust_hour.read_time,'01:00:00')=tmp4.read_time  
set eachcust_hour.meter_reading_t_1=tmp4.meter_reading;

update eachcust_hour
left join tmp4
on eachcust_hour.customer_id=tmp4.customer_id and subtime(eachcust_hour.read_time,'02:00:00')=tmp4.read_time
set eachcust_hour.meter_reading_t_2=tmp4.meter_reading;


#########################

#create table allcust_15 min by aggregating mynonullpricetemp
create table allcust_15min as(
select read_time,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,monthofyear,day_week,isweekend,timeindex,avg(price) as price,avg(temperature) as temperature
from mynonullpricetemp
group by read_time);


#create table allcust_15 min by aggregating mynonullpricetemp for RTP custoemrs
create table allcust_15min_RTP as(
select read_time,monthofyear,timeindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from mynonullpricetemp
where contract_type_code='RTP'
group by read_time);


#create table allcust_15 min by aggregating mynonullpricetemp for tou custoemrs
create table allcust_15min_tou as(
select read_time,monthofyear,timeindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from mynonullpricetemp
where contract_type_code='TOU'
group by read_time);


#create table allcust_15 min by aggregating mynonullpricetemp for fixed custoemrs
create table allcust_15min_fixed as(
select read_time,monthofyear,timeindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from mynonullpricetemp
where contract_type_code='FIXED'
group by read_time);




######################
#create table allcust_hour by aggregating eachcust_hour
create table allcust_hour as(
select read_time,monthofyear,hourindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from eachcust_hour
group by read_time);


#create table allcust_hour_RTP by aggregating eachcust_hour for RTP customers
create table allcust_hour_RTP as(
select read_time,monthofyear,hourindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from eachcust_hour
where contract_type_code='RTP'
group by read_time);


#create table allcust_hour_TOU by aggregating eachcust_hour for TOU customers
create table allcust_hour_TOU as(
select read_time,monthofyear,hourindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from eachcust_hour
where contract_type_code='TOU'
group by read_time);



#create table allcust_hour_RTP by aggregating eachcust_hour for FIXED customers
create table allcust_hour_FIXED as(
select read_time,monthofyear,hourindex,sum(meter_reading) as meter_reading,sum(meter_reading_t_1) as meter_reading_t_1,sum(meter_reading_t_2) as meter_reading_t_2,avg(price) as price,avg(temperature) as temperature,day_week,isweekend
from eachcust_hour
where contract_type_code='FIXED'
group by read_time);



#create table eachRTPcust_hour 
create table eachRTPcust_hour as(
select *
from eachcust_hour
where contract_type_code='RTP');


